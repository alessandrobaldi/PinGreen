PinGreen
NASA SpaceApps Challenge
The Earth and Us
Live Smart

Getting Started
PinGreen is a Smart Sensor and Application to help planting in green roofs. The app has charts with plants sensors and a collaborative way to exchange fruits and vegetables.

In the course of time, the growth of the urbans centers emerged. It is noticeable that the local temperature have increased a lot, this phenomenon is known as heat island.
But, what is a heat island? Heat island is a climatic phenomenon that happens on cities with a high urbanization rate. In these cities, the average temperature is usually higher than the rural regions that are close.
A way to avoid this phenomenon are the green roofs. This idea consists in planting on the house's roof, helping on the beauty of building, repealing the solar rays and keeping the ambience more cool in hot weather, and being a thermic insulation in cold days.
Our idea is a way to utilize these green roofs in planting vegetables and fruits with sensorized nodes, creating an intelligent subsistence farming at own home. In case of the over production, the person can made exchanges with other houses that has the same green roof.
To help this idea, we made PinGreen. PinGreen is a smart app what help you to take care of your roof’s garden. With assistance of humidity and temperature sensors on the plants and a system to stocks water in a more inteligent way, the app will maximize the roof planting experience for the users.
Besides that, you can find on PinGreen a food exchange system on the region, just need to put the food that wants to exchange or search in a list of options with swaps in region.

In the future, PinGreen can show a calendar system that will advise when is the best period to plant your favorite vegetable, give tips about planting, collect data to Artificial Intelligence algorithms and take care of the roof automatically. There are more advanced features that we doesn't have implemented in this hackathon because of time. 

Prerequisites
You need an Android device to run the MVP (Minimun Viable Product). The Arduino with sensors and Xively Key can send data to this MVP.

Installing
Using Sensors in Arduino and making a key in Xively, just install the apk in Android Smartphone.

Built With
Arduino - IDE for coding and electronic prototype device.
MIT App Inventor - For APP development.
Xively - Internet of Things platform communication.

Authors
Alessandro Murta Baldi - Original Idea, Programming
Bruno Loyola Barbosa - Programming
Eduardo Paulino dos Santos Fonseca - Images
João Victor Marçal Bragança - Programming, Text, Layout
Klara Matos Gazoli - 3D Modelling
Marinês de Jesus Rocha Barros - Images, Layout, Presentation
Pedro Henrique Siqueira Costa - Programming, Backend
Thallys Simões de Moraes Oliveira - 3D Modelling
Wyctor Fogos da Rocha - Programming

License
This project is licensed under the GNU GENERAL PUBLIC LICENSE - see the LICENSE.md file for details

Acknowledgments
